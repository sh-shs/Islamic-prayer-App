import 'package:flutter/material.dart';
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});
  static const items = <String>[
    'Prophet Muhammad ﷺ — a concise timeline of major events can be added and reviewed from reliable scholarly sources.',
    'The Hijrah — the migration from Makkah to Madinah became the starting point of the Hijri calendar.',
    'Madinah period — the Muslim community developed around worship, brotherhood, justice, and social responsibility.',
    'The preservation of knowledge — generations of scholars transmitted Quranic, prophetic, legal, and historical knowledge.',
    'Islamic civilization — contributions in mathematics, medicine, astronomy, architecture, literature, and education shaped world history.'
  ];
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Islamic History')), body: ListView.builder(padding: const EdgeInsets.all(16), itemCount: items.length, itemBuilder: (_, i) => Card(child: Padding(padding: const EdgeInsets.all(18), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [CircleAvatar(child: Text('${i+1}')), const SizedBox(width: 14), Expanded(child: Text(items[i], style: const TextStyle(height: 1.5)))])))));
}
