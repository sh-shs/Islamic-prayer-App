/// Represents one day's five prayers + sunrise, in the device's local time.
class PrayerDay {
  final DateTime fajr;
  final DateTime sunrise;
  final DateTime dhuhr;
  final DateTime asr;
  final DateTime maghrib;
  final DateTime isha;

  const PrayerDay({
    required this.fajr,
    required this.sunrise,
    required this.dhuhr,
    required this.asr,
    required this.maghrib,
    required this.isha,
  });

  /// Ordered list of the 5 obligatory prayers (excludes sunrise), used for
  /// building the prayer list UI and scheduling azan alarms.
  List<MapEntry<String, DateTime>> get fivePrayers => [
        MapEntry('fajr', fajr),
        MapEntry('dhuhr', dhuhr),
        MapEntry('asr', asr),
        MapEntry('maghrib', maghrib),
        MapEntry('isha', isha),
      ];

  /// Returns the next upcoming prayer relative to [now], or null if all of
  /// today's prayers have passed (caller should then compute tomorrow's Fajr).
  MapEntry<String, DateTime>? nextPrayer(DateTime now) {
    for (final p in fivePrayers) {
      if (p.value.isAfter(now)) return p;
    }
    return null;
  }
}
