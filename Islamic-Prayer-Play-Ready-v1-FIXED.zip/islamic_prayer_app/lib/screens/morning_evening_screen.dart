import 'package:flutter/material.dart';

class MorningEveningScreen extends StatelessWidget {
  const MorningEveningScreen({super.key});

  static const items = <(String, String, String)>[
    ('Morning', 'Ayat al-Kursi', 'Recite as part of your morning remembrance.'),
    ('Morning', 'SubhanAllahi wa bihamdihi', 'A simple daily remembrance.'),
    ('Morning', 'La ilaha illallahu wahdahu la sharika lah', 'Remember Allah and renew your tawhid.'),
    ('Evening', 'Ayat al-Kursi', 'Recite as part of your evening remembrance.'),
    ('Evening', 'SubhanAllahi wa bihamdihi', 'A simple evening remembrance.'),
    ('Evening', 'Allahumma inni as’alukal afiyah', 'Ask Allah for wellbeing and protection.'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Morning & Evening Amal')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (_, index) {
          final item = items[index];
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Chip(label: Text(item.$1)),
                  const SizedBox(height: 6),
                  Text(item.$2, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  Text(item.$3, style: const TextStyle(height: 1.5)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
