import 'package:shared_preferences/shared_preferences.dart';

class AmalTracker {
  static const _dateKey = 'amal_date';
  static const _itemsKey = 'amal_items';
  static const _streakKey = 'amal_streak';

  static Future<Map<String, bool>> loadToday() async {
    final prefs = await SharedPreferences.getInstance();
    final today = _date();
    if (prefs.getString(_dateKey) != today) {
      await prefs.setString(_dateKey, today);
      await prefs.setStringList(_itemsKey, <String>[]);
    }
    final done = prefs.getStringList(_itemsKey) ?? <String>[];
    return {for (final key in items) key: done.contains(key)};
  }

  static Future<void> setDone(String key, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    final current = (prefs.getStringList(_itemsKey) ?? <String>[]).toSet();
    value ? current.add(key) : current.remove(key);
    await prefs.setStringList(_itemsKey, current.toList());
    await _updateStreak(prefs);
  }

  static Future<int> streak() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_streakKey) ?? 0;
  }

  static Future<void> _updateStreak(SharedPreferences prefs) async {
    final done = prefs.getStringList(_itemsKey) ?? <String>[];
    if (done.length == items.length) {
      final last = prefs.getString('amal_last_complete');
      final today = _date();
      if (last != today) {
        final yesterday = DateTime.now().subtract(const Duration(days: 1));
        final y = '${yesterday.year.toString().padLeft(4, '0')}-${yesterday.month.toString().padLeft(2, '0')}-${yesterday.day.toString().padLeft(2, '0')}';
        final old = prefs.getInt(_streakKey) ?? 0;
        await prefs.setInt(_streakKey, last == y ? old + 1 : 1);
        await prefs.setString('amal_last_complete', today);
      }
    }
  }

  static String _date() {
    final n = DateTime.now();
    return '${n.year.toString().padLeft(4, '0')}-${n.month.toString().padLeft(2, '0')}-${n.day.toString().padLeft(2, '0')}';
  }

  static const items = <String>[
    'Fajr prayer',
    'Dhuhr prayer',
    'Asr prayer',
    'Maghrib prayer',
    'Isha prayer',
    'Morning adhkar',
    'Evening adhkar',
    'Daily dua',
  ];
}
