import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';

import '../models/prayer_day.dart';

/// Big hero card at the top of the Home screen: which prayer is next and a
/// live HH:MM:SS countdown. This is the "premium feel" focal point.
class CountdownCard extends StatelessWidget {
  final PrayerDay day;
  final DateTime now;

  const CountdownCard({super.key, required this.day, required this.now});

  @override
  Widget build(BuildContext context) {
    final next = day.nextPrayer(now);
    final scheme = Theme.of(context).colorScheme;

    if (next == null) {
      // All of today's prayers passed; tomorrow's Fajr will show once the
      // app reloads at midnight / next open.
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text('all_prayers_done_today'.tr(), textAlign: TextAlign.center),
        ),
      );
    }

    final remaining = next.value.difference(now);
    final h = remaining.inHours.toString().padLeft(2, '0');
    final m = (remaining.inMinutes % 60).toString().padLeft(2, '0');
    final s = (remaining.inSeconds % 60).toString().padLeft(2, '0');

    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [scheme.primary.withOpacity(0.85), scheme.primary.withOpacity(0.55)],
        ),
      ),
      child: Column(
        children: [
          Text('next_prayer'.tr(), style: TextStyle(color: scheme.onPrimary.withOpacity(0.85))),
          const SizedBox(height: 6),
          Text(
            next.key.tr(),
            style: TextStyle(
              color: scheme.onPrimary,
              fontSize: 32,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 12),
          Text(
            '$h:$m:$s',
            style: TextStyle(
              color: scheme.onPrimary,
              fontSize: 40,
              fontWeight: FontWeight.w300,
              letterSpacing: 2,
            ),
          ),
        ],
      ),
    );
  }
}
