import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('About')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset('assets/icon/app_icon.png', width: 110, height: 110),
              const SizedBox(height: 18),
              const Text('Islamic Prayer', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              const Text('Prayer times • Azan • Qibla • Amal', textAlign: TextAlign.center),
              const SizedBox(height: 18),
              const Text('Built by WebWorldBD', style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              const Text('Version 1.0.0', style: TextStyle(fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}
