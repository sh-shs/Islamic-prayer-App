import 'package:flutter/material.dart';
import '../services/amal_tracker.dart';

class TrackingScreen extends StatefulWidget {
  const TrackingScreen({super.key});
  @override State<TrackingScreen> createState() => _TrackingScreenState();
}
class _TrackingScreenState extends State<TrackingScreen> {
  Map<String, bool> _done = {};
  int _streak = 0;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final d = await AmalTracker.loadToday();
    final st = await AmalTracker.streak();
    if (mounted) setState(() { _done = d; _streak = st; });
  }
  @override Widget build(BuildContext context) {
    final completed = _done.values.where((v) => v).length;
    return Scaffold(
      appBar: AppBar(title: const Text('Amal Tracking')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(20), child: Row(children: [
          const CircleAvatar(radius: 28, child: Icon(Icons.local_fire_department_outlined)), const SizedBox(width: 14),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('$_streak day streak', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)), Text('$completed/${AmalTracker.items.length} completed today')]),
        ]))),
        const SizedBox(height: 12),
        LinearProgressIndicator(value: AmalTracker.items.isEmpty ? 0 : completed / AmalTracker.items.length, minHeight: 8, borderRadius: BorderRadius.circular(8)),
        const SizedBox(height: 16),
        ...AmalTracker.items.map((item) => Card(child: CheckboxListTile(value: _done[item] ?? false, title: Text(item), secondary: const Icon(Icons.check_circle_outline), onChanged: (v) async { await AmalTracker.setDone(item, v ?? false); await _load(); })) ),
      ]),
    );
  }
}
