import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:intl/intl.dart';

/// One row in the prayer-times list. Highlights the upcoming prayer so the
/// screen reads as premium/deliberate rather than a flat plain list.
class PrayerTile extends StatelessWidget {
  final String name; // 'fajr' | 'dhuhr' | 'asr' | 'maghrib' | 'isha'
  final DateTime time;
  final bool isNext;

  const PrayerTile({
    super.key,
    required this.name,
    required this.time,
    required this.isNext,
  });

  IconData get _icon {
    switch (name) {
      case 'fajr':
        return Icons.nights_stay_outlined;
      case 'dhuhr':
        return Icons.wb_sunny_outlined;
      case 'asr':
        return Icons.light_mode_outlined;
      case 'maghrib':
        return Icons.wb_twilight_outlined;
      case 'isha':
        return Icons.bedtime_outlined;
      default:
        return Icons.access_time;
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Container(
        decoration: isNext
            ? BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: scheme.primary, width: 1.4),
              )
            : null,
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: isNext ? scheme.primary : scheme.surfaceContainerHighest,
            child: Icon(_icon, color: isNext ? scheme.onPrimary : scheme.onSurfaceVariant),
          ),
          title: Text(
            name.tr(),
            style: TextStyle(fontWeight: isNext ? FontWeight.w700 : FontWeight.w500),
          ),
          trailing: Text(
            DateFormat.jm().format(time),
            style: Theme.of(context).textTheme.titleMedium,
          ),
        ),
      ),
    );
  }
}
