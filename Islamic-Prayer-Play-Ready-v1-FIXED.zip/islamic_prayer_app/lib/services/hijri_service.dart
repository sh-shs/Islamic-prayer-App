import 'package:hijri/hijri_calendar.dart';

/// Wraps the `hijri` package so the rest of the app doesn't need to know
/// which calculation offset is used. Adjust [_adjustment] by +/-1 day if
/// your local moon-sighting committee's dates differ from the calculated
/// Umm al-Qura calendar (common and expected — mention this in Settings
/// as an "Hijri date adjustment" control if you want users to fix it
/// themselves).
class HijriService {
  static const int _adjustment = 0;

  static HijriCalendar today() {
    final cal = HijriCalendar.now();
    if (_adjustment != 0) {
      cal.hDay += _adjustment;
    }
    return cal;
  }

  static String formatted(HijriCalendar h) {
    return '${h.hDay} ${h.longMonthName} ${h.hYear}';
  }

  /// Ramadan is Hijri month 9.
  static bool isRamadan(HijriCalendar h) => h.hMonth == 9;
}
