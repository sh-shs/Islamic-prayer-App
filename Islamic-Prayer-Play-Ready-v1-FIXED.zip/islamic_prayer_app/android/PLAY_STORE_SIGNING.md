# Google Play release signing

The project intentionally does **not** contain a private keystore. Never commit a keystore or passwords to GitHub.

For a Play release, create an upload keystore and configure either:

1. Android Studio/your local `key.properties`, or
2. GitHub Actions secrets and a release signing block.

Required values:
- `keyAlias`
- `keyPassword`
- `storePassword`
- path to the upload keystore

Google Play App Signing is recommended. Keep the upload keystore and its password in a secure backup.

The workflow can still verify/analyze/build the project without a production signing key, but the final AAB must be signed with your upload key before it is submitted to Play Console.


## Exact alarm note
The app uses `SCHEDULE_EXACT_ALARM` because prayer-time Azan is a user-facing precisely timed reminder. The app requests this special access at runtime. Do not replace it with `USE_EXACT_ALARM` without checking the current Google Play policy and declaration requirements.
