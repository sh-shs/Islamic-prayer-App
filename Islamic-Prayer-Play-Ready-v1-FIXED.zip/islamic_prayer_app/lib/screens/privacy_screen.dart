import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class PrivacyScreen extends StatelessWidget {
  const PrivacyScreen({super.key});

  static const privacyPolicyUrl = 'https://sh-shs.github.io/privacy-policy/';

  Future<void> _openPolicy() async {
    final uri = Uri.parse(privacyPolicyUrl);
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Privacy Policy')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Islamic Prayer Privacy Policy', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),
          const Text(
            'Islamic Prayer uses location on your device to calculate local prayer times and Qibla direction. The current app does not use a WebWorldBD backend to collect or store your location.',
            style: TextStyle(height: 1.6),
          ),
          const SizedBox(height: 14),
          const Text(
            'Notifications, scheduled alarms and the bundled Azan audio are used for prayer-time reminders. Settings such as language, theme, calculation method and Azan switches are stored locally on the device.',
            style: TextStyle(height: 1.6),
          ),
          const SizedBox(height: 14),
          const Text(
            'The Nearby Mosques feature may open Google Maps, and the Shopping shortcut opens SHS Bazar. These third-party services have their own privacy policies and terms.',
            style: TextStyle(height: 1.6),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: _openPolicy,
            icon: const Icon(Icons.open_in_new),
            label: const Text('View Full Privacy Policy'),
          ),
          const SizedBox(height: 10),
          SelectableText(
            privacyPolicyUrl,
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}
