import 'dart:async';

import 'package:adhan/adhan.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/prayer_day.dart';
import '../services/hijri_service.dart';
import '../services/location_service.dart';
import '../services/notification_service.dart';
import '../services/prayer_time_service.dart';
import '../services/settings_provider.dart';
import '../widgets/countdown_card.dart';
import '../widgets/prayer_tile.dart';
import '../widgets/quick_action_card.dart';
import 'about_screen.dart';
import 'calendar_screen.dart';
import 'dua_screen.dart';
import 'history_screen.dart';
import 'morning_evening_screen.dart';
import 'names_screen.dart';
import 'privacy_screen.dart';
import 'qibla_screen.dart';
import 'quiz_screen.dart';
import 'ramadan_screen.dart';
import 'settings_screen.dart';
import 'tasbih_screen.dart';
import 'tracking_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _service = PrayerTimeService();
  PrayerDay? _today;
  String? _errorKey;
  Timer? _ticker;
  DateTime _now = DateTime.now();
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    _load();
    _ticker = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    final settings = context.read<SettingsProvider>();
    try {
      final position = await LocationService.instance.getCurrentPosition();
      String? label;
      try {
        final marks = await placemarkFromCoordinates(position.latitude, position.longitude);
        if (marks.isNotEmpty) {
          final mark = marks.first;
          label = <String?>[
            mark.locality,
            mark.subAdministrativeArea,
            mark.country,
          ].whereType<String>().where((v) => v.trim().isNotEmpty).join(', ');
        }
      } catch (_) {}

      await settings.saveLocation(position.latitude, position.longitude, label: label);
      final params = _service.resolveParameters(settings.calculationMethod);
      final madhab = settings.madhab == 'Hanafi' ? Madhab.hanafi : Madhab.shafi;
      final days = List.generate(
        30,
        (index) => _service.calculateFor(
          latitude: position.latitude,
          longitude: position.longitude,
          date: DateTime.now().add(Duration(days: index)),
          params: params,
          madhab: madhab,
        ),
      );

      if (!mounted) return;
      setState(() {
        _today = days.first;
        _errorKey = null;
      });

      await NotificationService.instance.scheduleForDays(
        days: days,
        enabled: {
          'fajr': settings.fajrAzan,
          'dhuhr': settings.dhuhrAzan,
          'asr': settings.asrAzan,
          'maghrib': settings.maghribAzan,
          'isha': settings.ishaAzan,
        },
        masterEnabled: settings.azanEnabled,
        vibrationEnabled: settings.vibrationEnabled,
      );
    } catch (_) {
      if (settings.lastLatitude != null && settings.lastLongitude != null) {
        final params = _service.resolveParameters(settings.calculationMethod);
        final day = _service.calculateFor(
          latitude: settings.lastLatitude!,
          longitude: settings.lastLongitude!,
          date: DateTime.now(),
          params: params,
          madhab: settings.madhab == 'Hanafi' ? Madhab.hanafi : Madhab.shafi,
        );
        if (mounted) {
          setState(() {
            _today = day;
            _errorKey = 'using_last_known_location';
          });
        }
        final madhab = settings.madhab == 'Hanafi' ? Madhab.hanafi : Madhab.shafi;
        final days = List.generate(
          30,
          (index) => _service.calculateFor(
            latitude: settings.lastLatitude!,
            longitude: settings.lastLongitude!,
            date: DateTime.now().add(Duration(days: index)),
            params: params,
            madhab: madhab,
          ),
        );
        await NotificationService.instance.scheduleForDays(
          days: days,
          enabled: {
            'fajr': settings.fajrAzan,
            'dhuhr': settings.dhuhrAzan,
            'asr': settings.asrAzan,
            'maghrib': settings.maghribAzan,
            'isha': settings.ishaAzan,
          },
          masterEnabled: settings.azanEnabled,
          vibrationEnabled: settings.vibrationEnabled,
        );
      } else if (mounted) {
        setState(() => _errorKey = 'location_error');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Islamic Prayer', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            tooltip: 'Qibla',
            icon: const Icon(Icons.explore_outlined),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const QiblaScreen()),
            ),
          ),
          IconButton(
            tooltip: 'Settings',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ).then((_) => _load()),
          ),
        ],
      ),
      body: IndexedStack(
        index: _tab,
        children: [_home(), _prayerTab(), _amalTab(), _moreTab()],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (value) => setState(() => _tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.mosque_outlined), selectedIcon: Icon(Icons.mosque), label: 'Prayer'),
          NavigationDestination(icon: Icon(Icons.volunteer_activism_outlined), selectedIcon: Icon(Icons.volunteer_activism), label: 'Amal'),
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), selectedIcon: Icon(Icons.grid_view_rounded), label: 'More'),
        ],
      ),
    );
  }

  Widget _home() {
    if (_today == null) return _loading();
    final next = _today!.nextPrayer(_now);
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 30),
        children: [
          if (_errorKey != null) _notice(_errorKey!),
          _heroLocation(),
          const SizedBox(height: 10),
          Center(child: Text(HijriService.formatted(HijriService.today()))),
          const SizedBox(height: 12),
          CountdownCard(day: _today!, now: _now),
          const SizedBox(height: 16),
          if (next != null)
            Card(
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.notifications_active_outlined)),
                title: Text('Next: ${next.key.capitalize()}'),
                subtitle: Text(DateFormat('hh:mm a').format(next.value)),
                trailing: const Icon(Icons.chevron_right),
              ),
            ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: QuickActionCard(
                  icon: Icons.explore_outlined,
                  label: 'Qibla',
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QiblaScreen())),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: QuickActionCard(
                  icon: Icons.radio_button_checked,
                  label: 'Tasbih',
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TasbihScreen())),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(
                child: QuickActionCard(
                  icon: Icons.menu_book_outlined,
                  label: 'Daily Dua',
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DuaScreen())),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: QuickActionCard(
                  icon: Icons.nightlight_round,
                  label: 'Ramadan',
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RamadanScreen(today: _today!))),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _shoppingCard(),
          const SizedBox(height: 12),
          Text('Today’s prayers', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
          ..._today!.fivePrayers.map((prayer) => PrayerTile(name: prayer.key, time: prayer.value, isNext: next?.key == prayer.key)),
        ],
      ),
    );
  }

  Widget _prayerTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Prayer Times', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        if (_today != null)
          ..._today!.fivePrayers.map((prayer) => PrayerTile(
                name: prayer.key,
                time: prayer.value,
                isNext: _today!.nextPrayer(_now)?.key == prayer.key,
              )),
      ],
    );
  }

  Widget _amalTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Amal', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        _feature(Icons.radio_button_checked, 'Tasbih / Zikir', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TasbihScreen()))),
        _feature(Icons.menu_book_outlined, 'Daily Dua', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DuaScreen()))),
        _feature(Icons.wb_twilight_outlined, 'Morning & Evening Amal', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MorningEveningScreen()))),
        _feature(Icons.track_changes_outlined, 'Amal Tracking', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TrackingScreen()))),
        _feature(Icons.local_fire_department_outlined, 'Streak & Daily Summary', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TrackingScreen()))),
      ],
    );
  }

  Widget _moreTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('More', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        _feature(Icons.calendar_month_outlined, 'Islamic Calendar', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CalendarScreen()))),
        _feature(Icons.quiz_outlined, 'Islamic Quiz', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QuizScreen()))),
        _feature(Icons.auto_awesome_outlined, '99 Names of Allah', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NamesScreen()))),
        _feature(Icons.history_edu_outlined, 'Islamic History', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HistoryScreen()))),
        _feature(Icons.location_city_outlined, 'Nearby Mosques', _openMosques),
        _feature(Icons.search_outlined, 'Search', _openSearch),
        _feature(Icons.share_outlined, 'Share App', () => Share.share('Islamic Prayer — prayer times, Azan, Qibla and daily Amal.')),
        _feature(Icons.shopping_bag_outlined, 'Shopping • SHS Bazar', () => launchUrl(Uri.parse('https://shs-bazar.pages.dev/'), mode: LaunchMode.externalApplication)),
        _feature(Icons.info_outline, 'About App', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutScreen()))),
        _feature(Icons.privacy_tip_outlined, 'Privacy Policy', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyScreen()))),
        _feature(Icons.settings_outlined, 'Settings', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
      ],
    );
  }

  Future<void> _openMosques() async {
    final settings = context.read<SettingsProvider>();
    final uri = settings.lastLatitude != null && settings.lastLongitude != null
        ? Uri.parse('https://www.google.com/maps/search/?api=1&query=${settings.lastLatitude},${settings.lastLongitude}+mosque')
        : Uri.parse('https://www.google.com/maps/search/?api=1&query=mosque');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  void _openSearch() {
    showSearch(context: context, delegate: _FeatureSearchDelegate(this));
  }

  Widget _feature(IconData icon, String title, VoidCallback onTap) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }

  Widget _shoppingCard() {
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
        leading: const CircleAvatar(radius: 26, child: Icon(Icons.shopping_bag_outlined)),
        title: const Text('Shopping', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        subtitle: const Text('Buy everyday products from SHS Bazar'),
        trailing: FilledButton(
          onPressed: () => launchUrl(Uri.parse('https://shs-bazar.pages.dev/'), mode: LaunchMode.externalApplication),
          child: const Text('Shop'),
        ),
      ),
    );
  }

  Widget _heroLocation() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            const CircleAvatar(radius: 26, child: Icon(Icons.location_on_outlined)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Your location', style: Theme.of(context).textTheme.bodySmall),
                  Text(
                    context.watch<SettingsProvider>().locationLabel ?? 'Current location',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
                  ),
                ],
              ),
            ),
            IconButton(onPressed: _load, icon: const Icon(Icons.my_location_outlined)),
          ],
        ),
      ),
    );
  }

  Widget _loading() {
    return Center(child: _errorKey == null ? const CircularProgressIndicator() : _notice(_errorKey!));
  }

  Widget _notice(String key) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            const Icon(Icons.location_off_outlined, size: 36),
            const SizedBox(height: 8),
            Text(key.tr(), textAlign: TextAlign.center),
            const SizedBox(height: 8),
            FilledButton(onPressed: _load, child: const Text('Retry')),
          ],
        ),
      ),
    );
  }
}

class _FeatureSearchDelegate extends SearchDelegate<String> {
  _FeatureSearchDelegate(this.owner);

  final _HomeScreenState owner;

  static const items = [
    'Prayer Times',
    'Qibla',
    'Tasbih / Zikir',
    'Daily Dua',
    'Morning & Evening Amal',
    'Amal Tracking',
    'Streak & Daily Summary',
    'Islamic Calendar',
    'Islamic Quiz',
    '99 Names of Allah',
    'Islamic History',
    'Nearby Mosques',
    'Shopping • SHS Bazar',
    'Settings',
    'Privacy Policy',
    'About App',
  ];

  @override
  List<Widget>? buildActions(BuildContext context) => [
        IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear)),
      ];

  @override
  Widget? buildLeading(BuildContext context) => IconButton(
        onPressed: () => close(context, ''),
        icon: const Icon(Icons.arrow_back),
      );

  @override
  Widget buildResults(BuildContext context) => _build(context);

  @override
  Widget buildSuggestions(BuildContext context) => _build(context);

  Widget _build(BuildContext context) {
    final matches = items.where((item) => item.toLowerCase().contains(query.toLowerCase())).toList();
    return ListView(
      children: matches.map((item) {
        return ListTile(
          title: Text(item),
          trailing: const Icon(Icons.chevron_right),
          onTap: () {
            close(context, item);
            if (item == 'Nearby Mosques') {
              owner._openMosques();
            } else if (item == 'Shopping • SHS Bazar') {
              launchUrl(Uri.parse('https://shs-bazar.pages.dev/'), mode: LaunchMode.externalApplication);
            }
          },
        );
      }).toList(),
    );
  }
}

extension on String {
  String capitalize() => isEmpty ? this : '${this[0].toUpperCase()}${substring(1)}';
}
