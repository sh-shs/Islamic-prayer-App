import 'package:adhan/adhan.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/notification_service.dart';
import '../services/prayer_time_service.dart';
import '../services/settings_provider.dart';
import 'about_screen.dart';
import 'privacy_screen.dart';

const supportEmail = 'saripofficialsupport@gmail.com';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  static const languages = <String, Locale>{
    'English': Locale('en'),
    'বাংলা': Locale('bn'),
    'العربية': Locale('ar'),
    'हिन्दी': Locale('hi'),
  };

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    return Scaffold(
      appBar: AppBar(title: Text('settings'.tr())),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          const _SectionTitle('Appearance'),
          _Card(children: [
            SwitchListTile.adaptive(
              secondary: const Icon(Icons.dark_mode_outlined),
              title: const Text('Dark mode'),
              subtitle: const Text('Use the premium dark theme'),
              value: settings.darkMode,
              onChanged: settings.setDarkMode,
            ),
            const Divider(height: 1),
            SwitchListTile.adaptive(
              secondary: const Icon(Icons.access_time_outlined),
              title: const Text('24-hour time'),
              subtitle: const Text('Show prayer times in 24-hour format'),
              value: settings.use24Hour,
              onChanged: settings.set24Hour,
            ),
          ]),
          const _SectionTitle('Language'),
          _Card(children: [
            ListTile(
              leading: const Icon(Icons.translate_outlined),
              title: const Text('App language'),
              trailing: DropdownButtonHideUnderline(
                child: DropdownButton<Locale>(
                  value: context.locale,
                  items: languages.entries.map((entry) => DropdownMenuItem(value: entry.value, child: Text(entry.key))).toList(),
                  onChanged: (value) {
                    if (value != null) context.setLocale(value);
                  },
                ),
              ),
            ),
          ]),
          const _SectionTitle('Azan & Notifications'),
          _Card(children: [
            SwitchListTile.adaptive(
              secondary: const Icon(Icons.notifications_active_outlined),
              title: const Text('Azan notifications'),
              subtitle: const Text('Play Azan automatically at prayer time'),
              value: settings.azanEnabled,
              onChanged: (value) async {
                await NotificationService.instance.init();
                await settings.setAzanEnabled(value);
                await _reschedule(context);
              },
            ),
            const Divider(height: 1),
            _prayerSwitch(context, 'Fajr', 'fajr', settings),
            _prayerSwitch(context, 'Dhuhr', 'dhuhr', settings),
            _prayerSwitch(context, 'Asr', 'asr', settings),
            _prayerSwitch(context, 'Maghrib', 'maghrib', settings),
            _prayerSwitch(context, 'Isha', 'isha', settings),
            const Divider(height: 1),
            SwitchListTile.adaptive(
              secondary: const Icon(Icons.vibration_outlined),
              title: const Text('Vibration'),
              value: settings.vibrationEnabled,
              onChanged: settings.setVibration,
            ),
            ListTile(
              leading: const Icon(Icons.volume_up_outlined),
              title: const Text('Test Azan sound'),
              subtitle: const Text('Check the supplied Azan audio on this device'),
              trailing: const Icon(Icons.play_circle_outline),
              onTap: () async {
                await NotificationService.instance.init();
                await NotificationService.instance.testAzan();
              },
            ),
          ]),
          const _SectionTitle('Prayer calculation'),
          _Card(children: [
            ListTile(
              leading: const Icon(Icons.calculate_outlined),
              title: const Text('Calculation method'),
              subtitle: Text(settings.calculationMethod),
              trailing: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: settings.calculationMethod,
                  items: PrayerTimeService.selectableMethods.keys.map((method) => DropdownMenuItem(value: method, child: Text(method))).toList(),
                  onChanged: (value) async {
                    if (value == null) return;
                    await settings.setCalculationMethod(value);
                    await _reschedule(context);
                  },
                ),
              ),
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.mosque_outlined),
              title: const Text('Asr school / Madhab'),
              trailing: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: settings.madhab,
                  items: const [
                    DropdownMenuItem(value: 'Shafi', child: Text('Shafi')),
                    DropdownMenuItem(value: 'Hanafi', child: Text('Hanafi')),
                  ],
                  onChanged: (value) async {
                    if (value == null) return;
                    await settings.setMadhab(value);
                    await _reschedule(context);
                  },
                ),
              ),
            ),
          ]),
          const _SectionTitle('Location'),
          _Card(children: [
            ListTile(
              leading: const Icon(Icons.location_on_outlined),
              title: const Text('Current location'),
              subtitle: Text(settings.locationLabel ?? (settings.lastLatitude == null ? 'Not set' : '${settings.lastLatitude!.toStringAsFixed(4)}, ${settings.lastLongitude!.toStringAsFixed(4)}')),
              trailing: IconButton(
                icon: const Icon(Icons.my_location_outlined),
                onPressed: () async {
                  await Geolocator.openLocationSettings();
                },
              ),
            ),
            const Divider(height: 1),
            const ListTile(
              leading: Icon(Icons.gps_fixed_outlined),
              title: Text('Location permission'),
              subtitle: Text('Used to calculate local prayer times and Qibla direction.'),
            ),
          ]),
          const _SectionTitle('App'),
          _Card(children: [
            ListTile(
              leading: const Icon(Icons.shopping_bag_outlined),
              title: const Text('Shopping'),
              subtitle: const Text('Open SHS Bazar'),
              onTap: () => launchUrl(Uri.parse('https://shs-bazar.pages.dev/'), mode: LaunchMode.externalApplication),
            ),
            ListTile(
              leading: const Icon(Icons.support_agent_outlined),
              title: const Text('Contact support'),
              subtitle: const Text(supportEmail),
              onTap: () => launchUrl(Uri(scheme: 'mailto', path: supportEmail, query: 'subject=Islamic Prayer App Support')),
            ),
            ListTile(
              leading: const Icon(Icons.info_outline),
              title: const Text('About this app'),
              subtitle: const Text('Islamic Prayer • WebWorldBD'),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutScreen())),
            ),
            ListTile(
              leading: const Icon(Icons.privacy_tip_outlined),
              title: const Text('Privacy Policy'),
              subtitle: const Text('Read the in-app policy'),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyScreen())),
            ),
          ]),
          const SizedBox(height: 12),
          Center(child: Text('Islamic Prayer • v1.0.0', style: Theme.of(context).textTheme.bodySmall)),
        ],
      ),
    );
  }

  static Widget _prayerSwitch(BuildContext context, String label, String key, SettingsProvider settings) {
    return SwitchListTile.adaptive(
      secondary: const Icon(Icons.volume_up_outlined),
      title: Text(label),
      value: settings.isPrayerAzanEnabled(key),
      onChanged: (value) async {
        await settings.setPrayerAzan(key, value);
        await _reschedule(context);
      },
    );
  }

  static Future<void> _reschedule(BuildContext context) async {
    final settings = context.read<SettingsProvider>();
    if (settings.lastLatitude == null || settings.lastLongitude == null) return;
    final service = PrayerTimeService();
    final params = service.resolveParameters(settings.calculationMethod);
    final days = List.generate(
      7,
      (index) => service.calculateFor(
        latitude: settings.lastLatitude!,
        longitude: settings.lastLongitude!,
        date: DateTime.now().add(Duration(days: index)),
        params: params,
        madhab: settings.madhab == 'Hanafi' ? Madhab.hanafi : Madhab.shafi,
      ),
    );
    await NotificationService.instance.scheduleForDays(
      days: days,
      enabled: {
        'fajr': settings.fajrAzan,
        'dhuhr': settings.dhuhrAzan,
        'asr': settings.asrAzan,
        'maghrib': settings.maghribAzan,
        'isha': settings.ishaAzan,
      },
      masterEnabled: settings.azanEnabled,
      vibrationEnabled: settings.vibrationEnabled,
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 20, 4, 8),
        child: Text(text, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
      );
}

class _Card extends StatelessWidget {
  const _Card({required this.children});
  final List<Widget> children;
  @override
  Widget build(BuildContext context) => Card(child: Column(children: children));
}
