import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
// Aliased because easy_localization re-exports package:intl, which has its
// own TextDirection class (LTR/RTL/UNKNOWN) that shadows dart:ui's
// TextDirection (ltr/rtl) used by Text.textDirection below.
import 'dart:ui' as ui;

/// A short reference list of everyday duas. These are traditional,
/// widely-known short formulas (not a copyrighted translation of any
/// single author) with brief own-worded context for each — kept short by
/// design so this reads as a quick-reference card, not a full Hadith/Quran
/// app (that's a much bigger scope — see README "what's next").
class DuaScreen extends StatelessWidget {
  const DuaScreen({super.key});

  static const _duas = [
    _Dua(
      titleKey: 'dua_waking_up',
      arabic: 'الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ',
      contextKey: 'dua_waking_up_context',
    ),
    _Dua(
      titleKey: 'dua_before_eating',
      arabic: 'بِسْمِ اللَّهِ',
      contextKey: 'dua_before_eating_context',
    ),
    _Dua(
      titleKey: 'dua_after_eating',
      arabic: 'الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مُسْلِمِينَ',
      contextKey: 'dua_after_eating_context',
    ),
    _Dua(
      titleKey: 'dua_leaving_home',
      arabic: 'بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ',
      contextKey: 'dua_leaving_home_context',
    ),
    _Dua(
      titleKey: 'dua_entering_home',
      arabic: 'بِسْمِ اللَّهِ وَلَجْنَا وَبِسْمِ اللَّهِ خَرَجْنَا',
      contextKey: 'dua_entering_home_context',
    ),
    _Dua(
      titleKey: 'dua_before_sleep',
      arabic: 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا',
      contextKey: 'dua_before_sleep_context',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('daily_duas'.tr())),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _duas.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, i) {
          final dua = _duas[i];
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(dua.titleKey.tr(), style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  Text(
                    dua.arabic,
                    textDirection: ui.TextDirection.rtl,
                    style: const TextStyle(fontSize: 20, height: 1.6),
                  ),
                  const SizedBox(height: 8),
                  Text(dua.contextKey.tr(), style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _Dua {
  final String titleKey;
  final String arabic;
  final String contextKey;
  const _Dua({required this.titleKey, required this.arabic, required this.contextKey});
}
