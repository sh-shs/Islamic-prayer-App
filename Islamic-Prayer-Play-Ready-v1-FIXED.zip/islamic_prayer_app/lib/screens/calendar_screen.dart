import 'package:flutter/material.dart';
import '../services/hijri_service.dart';

class CalendarScreen extends StatelessWidget {
  const CalendarScreen({super.key});
  @override Widget build(BuildContext context) {
    final now = DateTime.now();
    final h = HijriService.today();
    return Scaffold(appBar: AppBar(title: const Text('Islamic Calendar')), body: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(24), child: Column(children: [
        const Icon(Icons.calendar_month_rounded, size: 48), const SizedBox(height: 12),
        Text(HijriService.formatted(h), style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800), textAlign: TextAlign.center),
        const SizedBox(height: 6), Text('${now.day}/${now.month}/${now.year} (Gregorian)'),
      ]))),
      const SizedBox(height: 12),
      const Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('Hijri dates are calculated locally'), subtitle: Text('Local moon-sighting committees may differ by one day.'))),
    ]));
  }
}
