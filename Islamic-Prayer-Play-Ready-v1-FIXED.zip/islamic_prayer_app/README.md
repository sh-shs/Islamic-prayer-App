# Islamic Prayer — Android

A premium Android-first Islamic prayer companion built with Flutter.

## Included
- Five daily prayer times
- GPS location and city label
- Qibla compass
- Hijri / Islamic calendar
- Tasbih / Zikir
- Daily Dua
- Morning & Evening Amal
- Ramadan / Suhoor / Iftar
- Amal tracking, daily summary and streak
- Islamic Quiz
- 99 Names of Allah
- Islamic History overview
- Nearby Mosques shortcut
- Search and Share
- Bangla / English / Arabic / Hindi framework
- Dark / Light mode
- Professional prayer/Azan settings
- Per-prayer Azan controls
- Supplied Azan MP3
- SHS Bazar shopping shortcut
- About and Privacy screens

## Azan
The supplied recording is `assets/audio/azan.mp3`.
The Android build copies it to `res/raw/azan.mp3` and uses it as the notification channel sound for Fajr, Dhuhr, Asr, Maghrib and Isha.

Users can enable/disable all Azan or each prayer separately. The app requests notification permission and exact-alarm access when required and safely falls back to an inexact idle-tolerant schedule if exact-alarm access is unavailable.

## Build
The GitHub Actions workflow:
1. creates the Android platform files,
2. sets package ID `com.webworldbd.islamicprayer`,
3. targets Android 16 / API 36,
4. injects only the required permissions,
5. copies the Azan audio,
6. generates launcher icons,
7. runs `flutter analyze`,
8. builds debug APK, release APK and release AAB.

The release AAB must be signed with your Google Play upload key before submission. The repository intentionally does not contain a private signing key.

## Important
This ZIP is source/build configuration, not proof of a successful production compile. The final compile and physical-device tests must pass before publishing. The public Privacy Policy URL and Play Console Data Safety form must be completed by the developer before release.


## Production / Google Play notes

- Package ID: `com.webworldbd.islamicprayer`
- Target/compile SDK: 36
- Release artifact: Android App Bundle (`.aab`)
- Public Privacy Policy: https://sh-shs.github.io/privacy-policy/
- Default app language: English; Bangla, Arabic and Hindi are available.
- Azan is enabled by default. Users can disable the master Azan switch or individual prayer Azan switches in Settings.
- Prayer times and Qibla calculation use device location; no WebWorldBD custom backend is used by the current source.
- Never commit a keystore, `key.properties`, or signing passwords. Configure Google Play App Signing/upload-key secrets separately.
- Before production release, build the signed release AAB and complete Play Console Data Safety, content rating, app access, privacy policy and any permission declarations based on the final binary.
