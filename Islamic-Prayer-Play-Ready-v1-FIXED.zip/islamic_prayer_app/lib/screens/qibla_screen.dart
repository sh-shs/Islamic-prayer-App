import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter_qiblah_advanced/flutter_qiblah_advanced.dart';

/// Live compass pointing toward the Kaaba. Requires a magnetometer, so
/// always show a graceful message on devices/emulators without one.
class QiblaScreen extends StatelessWidget {
  const QiblaScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('qibla'.tr())),
      body: FutureBuilder<bool?>(
        future: FlutterQiblah.androidDeviceSensorSupport(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          return StreamBuilder<QiblahDirection>(
            stream: FlutterQiblah.qiblahStream,
            builder: (context, snap) {
              if (!snap.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final direction = snap.data!;
              return Center(
                child: Transform.rotate(
                  angle: (direction.qiblah * (3.1415926535 / 180) * -1),
                  child: const Icon(Icons.explore, size: 220),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
