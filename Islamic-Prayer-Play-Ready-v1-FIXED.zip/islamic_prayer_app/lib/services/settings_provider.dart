import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsProvider extends ChangeNotifier {
  String calculationMethod = 'Muslim World League';
  String madhab = 'Shafi';
  double? lastLatitude;
  double? lastLongitude;
  String? locationLabel;
  bool azanEnabled = true;
  bool darkMode = true;
  bool use24Hour = false;
  bool fajrAzan = true;
  bool dhuhrAzan = true;
  bool asrAzan = true;
  bool maghribAzan = true;
  bool ishaAzan = true;
  bool vibrationEnabled = true;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    calculationMethod = prefs.getString('calc_method') ?? calculationMethod;
    madhab = prefs.getString('madhab') ?? madhab;
    lastLatitude = prefs.getDouble('lat');
    lastLongitude = prefs.getDouble('lng');
    locationLabel = prefs.getString('location_label');
    azanEnabled = prefs.getBool('azan_enabled') ?? true;
    darkMode = prefs.getBool('dark_mode') ?? true;
    use24Hour = prefs.getBool('use_24_hour') ?? false;
    fajrAzan = prefs.getBool('azan_fajr') ?? true;
    dhuhrAzan = prefs.getBool('azan_dhuhr') ?? true;
    asrAzan = prefs.getBool('azan_asr') ?? true;
    maghribAzan = prefs.getBool('azan_maghrib') ?? true;
    ishaAzan = prefs.getBool('azan_isha') ?? true;
    vibrationEnabled = prefs.getBool('vibration') ?? true;
    notifyListeners();
  }

  Future<void> _setBool(String key, bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(key, value);
    notifyListeners();
  }

  Future<void> saveLocation(double lat, double lng, {String? label}) async {
    lastLatitude = lat;
    lastLongitude = lng;
    if (label != null && label.trim().isNotEmpty) locationLabel = label.trim();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('lat', lat);
    await prefs.setDouble('lng', lng);
    if (locationLabel != null) await prefs.setString('location_label', locationLabel!);
    notifyListeners();
  }

  Future<void> setCalculationMethod(String value) async {
    calculationMethod = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('calc_method', value);
    notifyListeners();
  }

  Future<void> setMadhab(String value) async {
    madhab = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('madhab', value);
    notifyListeners();
  }

  Future<void> setAzanEnabled(bool value) async {
    azanEnabled = value;
    await _setBool('azan_enabled', value);
  }

  Future<void> setDarkMode(bool value) async {
    darkMode = value;
    await _setBool('dark_mode', value);
  }

  Future<void> set24Hour(bool value) async {
    use24Hour = value;
    await _setBool('use_24_hour', value);
  }

  Future<void> setPrayerAzan(String prayer, bool value) async {
    switch (prayer) {
      case 'fajr': fajrAzan = value; break;
      case 'dhuhr': dhuhrAzan = value; break;
      case 'asr': asrAzan = value; break;
      case 'maghrib': maghribAzan = value; break;
      case 'isha': ishaAzan = value; break;
    }
    await _setBool('azan_$prayer', value);
  }

  bool isPrayerAzanEnabled(String prayer) {
    switch (prayer) {
      case 'fajr': return fajrAzan;
      case 'dhuhr': return dhuhrAzan;
      case 'asr': return asrAzan;
      case 'maghrib': return maghribAzan;
      case 'isha': return ishaAzan;
      default: return false;
    }
  }

  Future<void> setVibration(bool value) async {
    vibrationEnabled = value;
    await _setBool('vibration', value);
  }
}
