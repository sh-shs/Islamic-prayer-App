# Privacy Policy — Islamic Prayer

Public URL: https://sh-shs.github.io/privacy-policy/

Developer: WebWorldBD  
Support: saripofficialsupport@gmail.com  
Effective date: September 17, 2026

The app uses device location to calculate prayer times and Qibla direction. The current app does not send location to a WebWorldBD backend. App preferences are stored locally. Notifications/alarms and bundled Azan audio are used for prayer reminders. Nearby Mosques can open Google Maps, and Shopping can open SHS Bazar; those third-party services have their own policies.

The full public policy is published at the URL above and is the URL to enter in Google Play Console.
