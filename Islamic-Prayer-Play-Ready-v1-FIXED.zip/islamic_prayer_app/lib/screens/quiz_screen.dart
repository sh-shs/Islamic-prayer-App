import 'package:flutter/material.dart';

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});
  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _Quiz {
  final String question;
  final List<String> answers;
  final int correct;
  const _Quiz(this.question, this.answers, this.correct);
}

class _QuizScreenState extends State<QuizScreen> {
  static const questions = <_Quiz>[
    _Quiz('How many obligatory daily prayers are there?', ['3', '4', '5', '6'], 2),
    _Quiz('Which month is Ramadan in the Hijri calendar?', ['7th', '8th', '9th', '10th'], 2),
    _Quiz('What is the direction Muslims face during Salah?', ['Jerusalem', 'Kaaba', 'Madinah', 'Mount Uhud'], 1),
    _Quiz('How many Names of Allah are commonly listed in the famous 99 Names collection?', ['77', '88', '99', '100'], 2),
    _Quiz('Which prayer is performed at dawn?', ['Fajr', 'Asr', 'Isha', 'Maghrib'], 0),
  ];

  int index = 0;
  int score = 0;
  bool answered = false;

  void _answer(int answer) {
    if (answered) return;
    setState(() => answered = true);
    if (answer == questions[index].correct) score++;
  }

  void _next() {
    if (index < questions.length - 1) {
      setState(() {
        index++;
        answered = false;
      });
      return;
    }
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Quiz complete'),
        content: Text('Score: $score/${questions.length}'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(dialogContext);
              setState(() {
                index = 0;
                score = 0;
                answered = false;
              });
            },
            child: const Text('Restart'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final quiz = questions[index];
    return Scaffold(
      appBar: AppBar(title: const Text('Islamic Quiz')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Question ${index + 1} of ${questions.length}'),
            const SizedBox(height: 12),
            Text(quiz.question, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 20),
            ...List.generate(
              quiz.answers.length,
              (answerIndex) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: OutlinedButton(
                  onPressed: () => _answer(answerIndex),
                  child: Align(alignment: Alignment.centerLeft, child: Padding(padding: const EdgeInsets.all(12), child: Text(quiz.answers[answerIndex]))),
                ),
              ),
            ),
            const Spacer(),
            if (answered) Text(index < questions.length - 1 ? 'Tap Next to continue' : 'Tap Finish to see your score'),
            const SizedBox(height: 8),
            if (answered) FilledButton(onPressed: _next, child: Text(index < questions.length - 1 ? 'Next' : 'Finish')),
          ],
        ),
      ),
    );
  }
}
