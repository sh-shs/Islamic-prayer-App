import 'package:adhan/adhan.dart';
import '../models/prayer_day.dart';

/// Wraps the `adhan` package to turn a GPS coordinate + calculation
/// settings into a [PrayerDay]. Calculation happens entirely on-device,
/// so once location is known the app needs no network connection.
class PrayerTimeService {
  /// [method] examples: CalculationMethod.muslim_world_league,
  /// CalculationMethod.karachi, CalculationMethod.egyptian,
  /// CalculationMethod.umm_al_qura, CalculationMethod.north_america, etc.
  /// Default to Muslim World League as a widely-accepted global default;
  /// expose this as a Settings option so users can pick what matches their
  /// local mosque.
  PrayerDay calculateFor({
    required double latitude,
    required double longitude,
    required DateTime date,
    CalculationParameters? params,
    Madhab madhab = Madhab.shafi,
  }) {
    final coordinates = Coordinates(latitude, longitude);
    final calcParams = params ?? CalculationMethod.muslim_world_league.getParameters();
    calcParams.madhab = madhab;

    final dateComponents = DateComponents.from(date);
    final prayerTimes = PrayerTimes(coordinates, dateComponents, calcParams);

    return PrayerDay(
      fajr: prayerTimes.fajr,
      sunrise: prayerTimes.sunrise,
      dhuhr: prayerTimes.dhuhr,
      asr: prayerTimes.asr,
      maghrib: prayerTimes.maghrib,
      isha: prayerTimes.isha,
    );
  }

  /// Qibla direction in degrees from true north, for the compass screen.
  double qiblaDirection({required double latitude, required double longitude}) {
    return Qibla(Coordinates(latitude, longitude)).direction;
  }

  /// Resolves the CalculationParameters for a given method name (as stored
  /// in Settings), falling back to Muslim World League if unknown.
  /// Centralized here (rather than duplicated at each call site) because
  /// `.getParameters()` is an extension method from package:adhan — it's
  /// only visible in files that import that package directly.
  CalculationParameters resolveParameters(String methodName) {
    final method = selectableMethods[methodName] ??
        selectableMethods['Muslim World League']!;
    return method.getParameters();
  }

  /// Map of selectable calculation methods for the Settings screen.
  static Map<String, CalculationMethod> selectableMethods = {
    'Muslim World League': CalculationMethod.muslim_world_league,
    'Umm al-Qura (Makkah)': CalculationMethod.umm_al_qura,
    'Egyptian': CalculationMethod.egyptian,
    'Karachi': CalculationMethod.karachi,
    'North America (ISNA)': CalculationMethod.north_america,
    'Dubai': CalculationMethod.dubai,
    'Qatar': CalculationMethod.qatar,
    'Kuwait': CalculationMethod.kuwait,
    'Singapore': CalculationMethod.singapore,
  };
}
