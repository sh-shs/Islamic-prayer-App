# Play Store release checklist

## Build target
- Android only
- Package ID: `com.webworldbd.islamicprayer`
- Target SDK: Android 16 / API 36
- Minimum SDK: 21
- Version: `1.0.0+1`
- Release artifact: `.aab`

Google Play currently requires new apps and app updates submitted from August 31, 2026 to target Android 16 (API 36) or higher. See the official Android requirement before each release.

## Implemented features
- Five prayer times
- Location-based calculation with last-known fallback
- Qibla compass
- Hijri/Islamic calendar
- Tasbih
- Daily duas
- Morning/evening Amal
- Ramadan/Suhoor/Iftar screen
- Amal tracking and streak
- Islamic quiz
- 99 Names of Allah
- Islamic history overview
- Nearby mosque shortcut using Google Maps
- Search
- Share
- About
- In-app privacy policy screen
- Bangla / English / Arabic / Hindi framework
- Dark/light mode
- Professional settings
- Per-prayer Azan controls
- Azan master switch
- Azan test button
- Local Azan MP3
- SHS Bazar shopping shortcut

## Runtime permissions
Only permissions needed by the current feature set are declared:
- `ACCESS_COARSE_LOCATION`
- `ACCESS_FINE_LOCATION`
- `POST_NOTIFICATIONS`
- `SCHEDULE_EXACT_ALARM`
- `RECEIVE_BOOT_COMPLETED`
- `VIBRATE`

No contacts, camera, microphone, SMS, phone, storage, or background-location permission is requested.

## Azan
- Supplied recording: `assets/audio/azan.mp3`
- Fajr, Dhuhr, Asr, Maghrib and Isha can be independently enabled/disabled.
- Master Azan switch can disable all scheduled Azan.
- The app schedules a rolling 30-day window when location/prayer settings are loaded.
- Exact scheduling is attempted; if exact-alarm access is unavailable, the app falls back to an idle-tolerant inexact schedule instead of crashing.
- Android notification permission and Alarms & reminders access may require user approval.
- Battery optimization on some OEM devices can still affect background delivery and must be tested on physical devices.

## Before publishing
1. Public Privacy Policy: https://sh-shs.github.io/privacy-policy/
2. Enter the same URL in Play Console and keep the in-app Privacy Policy button pointed to it.
3. Complete Google Play Data Safety based on the actual release build and any external services used.
4. Confirm you have permission to distribute the supplied Azan recording.
5. Configure Google Play App Signing and an upload key.
6. Increase `version`/`versionCode` for every subsequent release.
7. Test Android 13, 14, 15, 16 and representative Samsung/Xiaomi/OPPO devices where possible.
8. Test notification denial, exact-alarm denial, reboot, timezone change, location denial, battery saver, every prayer toggle and the Azan test button.
9. Upload the **signed release AAB**, not the debug APK.
