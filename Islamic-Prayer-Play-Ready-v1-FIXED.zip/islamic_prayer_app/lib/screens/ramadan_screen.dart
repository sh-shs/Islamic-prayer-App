import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';

import '../models/prayer_day.dart';
import '../services/hijri_service.dart';

class RamadanScreen extends StatefulWidget {
  const RamadanScreen({super.key, required this.today});
  final PrayerDay today;

  @override
  State<RamadanScreen> createState() => _RamadanScreenState();
}

class _RamadanScreenState extends State<RamadanScreen> {
  Timer? ticker;
  DateTime now = DateTime.now();

  @override
  void initState() {
    super.initState();
    ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => now = DateTime.now());
    });
  }

  @override
  void dispose() {
    ticker?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final hijri = HijriService.today();
    final isRamadan = HijriService.isRamadan(hijri);
    return Scaffold(
      appBar: AppBar(title: Text('ramadan'.tr())),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    Text('hijri_date'.tr()),
                    const SizedBox(height: 6),
                    Text(HijriService.formatted(hijri), style: Theme.of(context).textTheme.headlineSmall),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            if (isRamadan) _countdown(context) else _notRamadan(context),
          ],
        ),
      ),
    );
  }

  Widget _countdown(BuildContext context) {
    final suhoorEnd = widget.today.fajr;
    final iftar = widget.today.maghrib;
    final beforeSuhoor = now.isBefore(suhoorEnd);
    final target = beforeSuhoor ? suhoorEnd : iftar;
    final label = beforeSuhoor ? 'suhoor_ends_in'.tr() : 'iftar_in'.tr();
    final remaining = target.difference(now);
    final safe = remaining.isNegative ? Duration.zero : remaining;
    final h = safe.inHours.toString().padLeft(2, '0');
    final m = (safe.inMinutes % 60).toString().padLeft(2, '0');
    final sec = (safe.inSeconds % 60).toString().padLeft(2, '0');
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(children: [
          Text(label, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 12),
          Text('$h:$m:$sec', style: const TextStyle(fontSize: 40, fontWeight: FontWeight.w300, letterSpacing: 2)),
        ]),
      ),
    );
  }

  Widget _notRamadan(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Text('not_ramadan_yet'.tr(), textAlign: TextAlign.center),
      ),
    );
  }
}
