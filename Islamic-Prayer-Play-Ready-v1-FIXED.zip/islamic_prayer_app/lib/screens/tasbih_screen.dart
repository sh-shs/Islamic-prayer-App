import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Digital Tasbih / dhikr counter. Persists the count and target so it
/// survives app restarts (users often count across many sittings toward
/// a target like 100 or 1000).
class TasbihScreen extends StatefulWidget {
  const TasbihScreen({super.key});

  @override
  State<TasbihScreen> createState() => _TasbihScreenState();
}

class _TasbihScreenState extends State<TasbihScreen> {
  int _count = 0;
  int _target = 33;
  static const _dhikrOptions = ['SubhanAllah', 'Alhamdulillah', 'Allahu Akbar', 'La ilaha illallah'];
  String _selectedDhikr = 'SubhanAllah';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _count = prefs.getInt('tasbih_count') ?? 0;
      _target = prefs.getInt('tasbih_target') ?? 33;
      _selectedDhikr = prefs.getString('tasbih_dhikr') ?? 'SubhanAllah';
    });
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('tasbih_count', _count);
    await prefs.setInt('tasbih_target', _target);
    await prefs.setString('tasbih_dhikr', _selectedDhikr);
  }

  void _increment() {
    setState(() => _count++);
    _persist();
    if (_count == _target) {
      // Reaching the target is the natural "reward" moment for this
      // screen — a small haptic/visual cue here (not implemented to
      // avoid adding another plugin) would be a nice premium touch.
    }
  }

  void _reset() {
    setState(() => _count = 0);
    _persist();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final progress = (_count / _target).clamp(0.0, 1.0);

    return Scaffold(
      appBar: AppBar(title: Text('tasbih'.tr())),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Wrap(
              spacing: 8,
              children: _dhikrOptions
                  .map((d) => ChoiceChip(
                        label: Text(d),
                        selected: _selectedDhikr == d,
                        onSelected: (_) {
                          setState(() => _selectedDhikr = d);
                          _persist();
                        },
                      ))
                  .toList(),
            ),
          ),
          Expanded(
            child: Center(
              child: GestureDetector(
                onTap: _increment,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 220,
                      height: 220,
                      child: CircularProgressIndicator(
                        value: progress,
                        strokeWidth: 8,
                        backgroundColor: scheme.surfaceContainerHighest,
                        valueColor: AlwaysStoppedAnimation(scheme.primary),
                      ),
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('$_count', style: const TextStyle(fontSize: 56, fontWeight: FontWeight.w700)),
                        Text('/ $_target', style: Theme.of(context).textTheme.titleMedium),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
            child: Wrap(
              alignment: WrapAlignment.center,
              spacing: 8,
              runSpacing: 8,
              children: [
                OutlinedButton.icon(
                  onPressed: _reset,
                  icon: const Icon(Icons.refresh),
                  label: Text('reset'.tr()),
                ),
                ...[33, 99, 100, 1000].map((t) => ChoiceChip(
                      label: Text('$t'),
                      selected: _target == t,
                      onSelected: (_) {
                        setState(() => _target = t);
                        _persist();
                      },
                    )),
              ],
            ),
          ),
          Text('tasbih_hint'.tr(), style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}
