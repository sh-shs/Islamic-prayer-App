import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tz_data;
import 'package:timezone/timezone.dart' as tz;

import '../models/prayer_day.dart';

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  static const _channelId = 'azan_channel_v2';
  static const _channelName = 'Azan';
  static const _channelDescription = 'Azan notifications at the beginning of each prayer';

  Future<void> init() async {
    if (_initialized) return;
    tz_data.initializeTimeZones();
    try {
      final info = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(info.identifier));
    } catch (_) {
      tz.setLocalLocation(tz.getLocation('Asia/Dhaka'));
    }

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(const InitializationSettings(android: androidInit));

    final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await android?.requestNotificationsPermission();
    // SCHEDULE_EXACT_ALARM is user-granted on modern Android. Request it so
    // prayer-time Azan can be delivered as close to the calculated time as
    // possible. The scheduler below still has an inexact fallback.
    await android?.requestExactAlarmsPermission();
    _initialized = true;
  }

  Future<void> cancelAll() => _plugin.cancelAll();

  Future<void> scheduleForDays({
    required List<PrayerDay> days,
    required Map<String, bool> enabled,
    required bool masterEnabled,
    bool vibrationEnabled = true,
  }) async {
    await init();
    await _plugin.cancelAll();
    if (!masterEnabled) return;

    final androidDetails = AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: _channelDescription,
      importance: Importance.max,
      priority: Priority.max,
      playSound: true,
      sound: const RawResourceAndroidNotificationSound('azan'),
      category: AndroidNotificationCategory.alarm,
      visibility: NotificationVisibility.public,
      enableVibration: vibrationEnabled,
      audioAttributesUsage: AudioAttributesUsage.alarm,
    );
    final details = NotificationDetails(android: androidDetails);

    var id = 5000;
    // Keep a rolling 30-day schedule so Azan remains automatic even if the
    // user does not open the app for several days.

    for (final day in days) {
      for (final entry in day.fivePrayers) {
        if (enabled[entry.key] != true) continue;
        final scheduled = tz.TZDateTime.from(entry.value, tz.local);
        if (!scheduled.isAfter(tz.TZDateTime.now(tz.local))) continue;
        final notificationId = id++;
        try {
          await _plugin.zonedSchedule(
            notificationId,
            _title(entry.key),
            _body(entry.key, scheduled),
            scheduled,
            details,
            androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
            uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
            payload: entry.key,
          );
        } catch (_) {
          // Some devices/users do not grant exact-alarm access. Never crash;
          // fall back to an idle-tolerant inexact alarm instead.
          await _plugin.zonedSchedule(
            notificationId,
            _title(entry.key),
            _body(entry.key, scheduled),
            scheduled,
            details,
            androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
            uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
            payload: entry.key,
          );
        }
      }
    }
  }

  Future<void> scheduleDailyAzan(PrayerDay day) async {
    await scheduleForDays(
      days: [day],
      enabled: const {'fajr': true, 'dhuhr': true, 'asr': true, 'maghrib': true, 'isha': true},
      masterEnabled: true,
    );
  }

  Future<void> testAzan() async {
    await init();
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        _channelId,
        _channelName,
        channelDescription: _channelDescription,
        importance: Importance.max,
        priority: Priority.max,
        playSound: true,
        sound: RawResourceAndroidNotificationSound('azan'),
        category: AndroidNotificationCategory.alarm,
        audioAttributesUsage: AudioAttributesUsage.alarm,
      ),
    );
    await _plugin.show(99999, 'Azan Test', 'This is a test of the Azan sound.', details);
  }

  String _title(String prayer) => 'Prayer time • ${_label(prayer)}';
  String _body(String prayer, tz.TZDateTime time) => 'It is time for ${_label(prayer)} • ${_format(time)}';
  String _label(String prayer) => prayer[0].toUpperCase() + prayer.substring(1);
  String _format(DateTime time) {
    final h = time.hour % 12 == 0 ? 12 : time.hour % 12;
    final m = time.minute.toString().padLeft(2, '0');
    return '$h:$m ${time.hour >= 12 ? 'PM' : 'AM'}';
  }
}
