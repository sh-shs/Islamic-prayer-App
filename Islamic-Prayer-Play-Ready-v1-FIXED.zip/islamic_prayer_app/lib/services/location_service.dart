import 'package:geolocator/geolocator.dart';

/// Handles GPS permission requests and fetching the current position.
///
/// Prayer time calculation only needs lat/long + timezone, so once we have
/// a position the app works fully offline — network is only used to help
/// acquire location faster and (optionally) to reverse-geocode a city name
/// for display.
class LocationService {
  LocationService._();
  static final LocationService instance = LocationService._();

  Future<Position> getCurrentPosition() async {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw LocationServiceDisabledException();
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw const LocationPermissionDeniedException();
      }
    }

    if (permission == LocationPermission.deniedForever) {
      throw const LocationPermissionDeniedException(forever: true);
    }

    return Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.medium),
    );
  }
}

class LocationPermissionDeniedException implements Exception {
  final bool forever;
  const LocationPermissionDeniedException({this.forever = false});
}
