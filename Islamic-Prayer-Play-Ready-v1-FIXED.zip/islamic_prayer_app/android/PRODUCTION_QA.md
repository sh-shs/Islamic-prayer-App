# Production QA before Play Store submission

This source is configured for Android-only release and Google Play target API 36.

Before the first production upload, build a **release AAB** and test on physical devices:

- Android 13, 14, 15 and 16 where possible.
- Notification permission granted and denied.
- Exact alarm access granted and denied.
- Location service on/off and permission granted/denied.
- Phone reboot and app update while alarms are scheduled.
- Each of Fajr/Dhuhr/Asr/Maghrib/Isha enabled and disabled.
- Master Azan ON/OFF.
- Azan test sound.
- Timezone change and daylight-saving regions.
- Battery saver/background restrictions on Samsung, Xiaomi/Redmi, OPPO/realme where available.
- Calculation method and Madhab changes.
- Dark/light mode and all four languages.
- Qibla sensor unavailable/available.
- SHS Bazar external link and support email.

Do not publish until the signed release AAB has passed these tests and the Play Console Data Safety / Privacy Policy declarations match the actual build.
